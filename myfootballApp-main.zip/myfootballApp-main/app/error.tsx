'use client'

export default function Error() {
    return (
        <div className="flex flex-col w-full justify-center items-center h-screen text-neutral-100">
            ERROR
        </div>
    )
}